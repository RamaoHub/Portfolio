document.addEventListener("DOMContentLoaded", () => {
  const skillItems = document.querySelectorAll(".skill-item");
  const galleryContainer = document.getElementById("artwork-gallery");
  const categories = document.querySelectorAll(".artwork-category");

  function showCategory(categoryId) {
    galleryContainer.classList.add("active");
    categories.forEach((cat) => {
      cat.classList.remove("active");
    });
    const targetCategory = document.getElementById(categoryId);
    if (targetCategory) {
      targetCategory.classList.add("active");
      galleryContainer.scrollIntoView({ behavior: "smooth" });
    }
  }

  skillItems.forEach((item) => {
    item.addEventListener("click", () => {
      const category = item.getAttribute("data-category");
      showCategory(`${category}-gallery`);
    });
  });

  const contactForm = document.querySelector(".contact-form");
  if (contactForm) {
    contactForm.addEventListener("submit", async (e) => {
      e.preventDefault();
      const formAction = contactForm.getAttribute("action");
      const formMethod = contactForm.getAttribute("method");
      try {
        const response = await fetch(formAction, {
          method: formMethod,
          body: new FormData(contactForm),
          headers: { Accept: "application/json" },
        });
        if (response.ok) {
          alert("Mensagem enviada com sucesso!");
          contactForm.reset();
        } else {
          alert("Erro ao enviar a mensagem. Tente novamente.");
        }
      } catch (error) {
        alert("Erro ao enviar a mensagem. Tente novamente.");
        console.error(error);
      }
    });
  }
});

// Botão de voltar ao topo
const topBtn = document.getElementById("topBtn");
window.onscroll = function () {
  if (
    document.body.scrollTop > 200 ||
    document.documentElement.scrollTop > 200
  ) {
    topBtn.style.display = "block";
  } else {
    topBtn.style.display = "none";
  }
};
topBtn.addEventListener("click", function () {
  window.scrollTo({ top: 0, behavior: "smooth" });
});

// Tema escuro/claro
const themeToggle = document.querySelector(".switch input");
const body = document.body;

// Verifica a preferência salva no localStorage
const savedTheme = localStorage.getItem("theme");
if (savedTheme === "light") {
  body.classList.add("light-mode");
  themeToggle.checked = true;
}

// Alterna o tema ao clicar no switch
themeToggle.addEventListener("change", function () {
  if (this.checked) {
    body.classList.add("light-mode");
    localStorage.setItem("theme", "light");
  } else {
    body.classList.remove("light-mode");
    localStorage.setItem("theme", "dark");
  }
});
